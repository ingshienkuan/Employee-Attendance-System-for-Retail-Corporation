// Shift Management System JavaScript

class ShiftManagement {
    constructor() {
        this.currentWeek = new Date('2023-05-15');
        this.selectedDepartment = 'all';
        this.activeTab = 'upcoming';
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateDateRange();
    }

    bindEvents() {
        // Department tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleDepartmentChange(e));
        });

        // Sub navigation
        document.querySelectorAll('.sub-nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleTabChange(e));
        });

        // Date navigation
        document.getElementById('prevWeek').addEventListener('click', () => this.navigateWeek(-1));
        document.getElementById('nextWeek').addEventListener('click', () => this.navigateWeek(1));

        // Date controls
        document.querySelectorAll('.date-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleDateControl(e));
        });

        // Create new shift button
        document.getElementById('createShiftBtn').addEventListener('click', () => this.createNewShift());

        // More buttons on shift cards
        document.querySelectorAll('.more-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleShiftMenu(e));
        });

        // Action buttons in pending requests
        document.querySelectorAll('.btn-action').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleRequestAction(e));
        });
    }

    handleDepartmentChange(e) {
        // Remove active class from all tabs
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked tab
        e.target.classList.add('active');
        
        this.selectedDepartment = e.target.dataset.dept;
        this.filterShiftsByDepartment();
    }

    handleTabChange(e) {
        // Remove active class from all sub-nav buttons
        document.querySelectorAll('.sub-nav-btn').forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked button
        e.target.classList.add('active');
        
        this.activeTab = e.target.textContent.toLowerCase().replace(' ', '');
        this.updateMainContent();
    }

    navigateWeek(direction) {
        const newDate = new Date(this.currentWeek);
        newDate.setDate(newDate.getDate() + (direction * 7));
        this.currentWeek = newDate;
        this.updateDateRange();
        this.updateScheduleData();
    }

    updateDateRange() {
        const startDate = new Date(this.currentWeek);
        const endDate = new Date(this.currentWeek);
        endDate.setDate(endDate.getDate() + 6);
        
        const options = { month: 'long', day: 'numeric', year: 'numeric' };
        const startStr = startDate.toLocaleDateString('en-US', options);
        const endStr = endDate.toLocaleDateString('en-US', options);
        
        // Format: "May 15 - May 21, 2023"
        const startParts = startStr.split(' ');
        const endParts = endStr.split(' ');
        
        let dateRangeText;
        if (startParts[0] === endParts[0]) { // Same month
            dateRangeText = `${startParts[0]} ${startParts[1].replace(',', '')} - ${endParts[1]}`;
        } else { // Different months
            dateRangeText = `${startParts[0]} ${startParts[1].replace(',', '')} - ${endParts[0]} ${endParts[1]}`;
        }
        
        document.querySelector('.date-range').textContent = dateRangeText;
    }

    handleDateControl(e) {
        const control = e.target.textContent.trim();
        
        switch(control) {
            case 'Today':
                this.goToToday();
                break;
            case 'This Week':
                this.goToThisWeek();
                break;
            case '📅 Calendar':
                this.openCalendar();
                break;
        }
    }

    goToToday() {
        const today = new Date();
        const monday = new Date(today);
        monday.setDate(today.getDate() - today.getDay() + 1);
        this.currentWeek = monday;
        this.updateDateRange();
        this.updateScheduleData();
    }

    goToThisWeek() {
        this.goToToday();
    }

    openCalendar() {
        // Placeholder for calendar functionality
        alert('Calendar feature would open here');
    }

    filterShiftsByDepartment() {
        const shiftCards = document.querySelectorAll('.shift-card');
        
        shiftCards.forEach(card => {
            const department = card.querySelector('h4').textContent;
            const shouldShow = this.selectedDepartment === 'all' || 
                              this.matchesDepartmentFilter(department);
            
            card.style.display = shouldShow ? 'block' : 'none';
        });
    }

    matchesDepartmentFilter(department) {
        const filterMap = {
            'sales': 'Sales & Customer Service',
            'inventory': 'Inventory & Supply Chain',
            'marketing': 'Marketing & Merchandising',
            'hr': 'HR',
            'finance': 'Finance & Accounting',
            'it': 'IT & E-commerce'
        };
        
        return department === filterMap[this.selectedDepartment];
    }

    updateMainContent() {
        // Hide/show different sections based on active tab
        const scheduleGrid = document.querySelector('.schedule-grid');
        const pendingRequests = document.querySelector('.pending-requests');
        
        switch(this.activeTab) {
            case 'upcomingshifts':
                scheduleGrid.style.display = 'grid';
                pendingRequests.style.display = 'block';
                break;
            case 'reassignshifts':
                scheduleGrid.style.display = 'grid';
                pendingRequests.style.display = 'none';
                this.showReassignView();
                break;
            case 'shiftchangerequests':
                scheduleGrid.style.display = 'none';
                pendingRequests.style.display = 'block';
                this.showChangeRequests();
                break;
            case 'leaverequests':
                scheduleGrid.style.display = 'none';
                pendingRequests.style.display = 'block';
                this.showLeaveRequests();
                break;
        }
    }

    showReassignView() {
        // Add visual indicators for reassignable shifts
        document.querySelectorAll('.shift-card').forEach(card => {
            card.classList.add('reassignable');
        });
    }

    showChangeRequests() {
        // Filter pending requests to show only shift change requests
        this.filterRequestsByType('Shift Change');
    }

    showLeaveRequests() {
        // Filter pending requests to show only leave requests
        this.filterRequestsByType('Leave Request');
    }

    filterRequestsByType(type) {
        document.querySelectorAll('.table-row').forEach(row => {
            const requestType = row.querySelector('.request-type');
            if (requestType) {
                const shouldShow = requestType.textContent === type;
                row.style.display = shouldShow ? 'grid' : 'none';
            }
        });
    }

    updateScheduleData() {
        // Placeholder for updating schedule data based on current week
        // In a real application, this would fetch data from an API
        console.log(`Loading schedule data for week of ${this.currentWeek.toDateString()}`);
    }

    createNewShift() {
        if (window.shiftModal) {
            window.shiftModal.openModal();
        }
    }

    handleShiftMenu(e) {
        e.stopPropagation();
        
        // Create context menu
        const menu = this.createContextMenu([
            { label: 'Edit Shift', action: 'edit' },
            { label: 'Reassign', action: 'reassign' },
            { label: 'Cancel Shift', action: 'cancel' },
            { label: 'View Details', action: 'details' }
        ]);
        
        this.showContextMenu(menu, e.target);
    }

    createContextMenu(items) {
        const menu = document.createElement('div');
        menu.className = 'context-menu';
        menu.style.cssText = `
            position: absolute;
            background: white;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            min-width: 120px;
        `;
        
        items.forEach(item => {
            const menuItem = document.createElement('div');
            menuItem.className = 'context-menu-item';
            menuItem.textContent = item.label;
            menuItem.style.cssText = `
                padding: 8px 12px;
                cursor: pointer;
                font-size: 14px;
                border-bottom: 1px solid #eee;
            `;
            
            menuItem.addEventListener('click', () => {
                this.handleContextMenuAction(item.action);
                menu.remove();
            });
            
            menuItem.addEventListener('mouseenter', () => {
                menuItem.style.backgroundColor = '#f8f9fa';
            });
            
            menuItem.addEventListener('mouseleave', () => {
                menuItem.style.backgroundColor = 'white';
            });
            
            menu.appendChild(menuItem);
        });
        
        // Remove border from last item
        menu.lastChild.style.borderBottom = 'none';
        
        return menu;
    }

    showContextMenu(menu, trigger) {
        document.body.appendChild(menu);
        
        const rect = trigger.getBoundingClientRect();
        menu.style.left = rect.left + 'px';
        menu.style.top = (rect.bottom + 5) + 'px';
        
        // Close menu when clicking outside
        const closeMenu = (e) => {
            if (!menu.contains(e.target)) {
                menu.remove();
                document.removeEventListener('click', closeMenu);
            }
        };
        
        setTimeout(() => {
            document.addEventListener('click', closeMenu);
        }, 0);
    }

    handleContextMenuAction(action) {
        switch(action) {
            case 'edit':
                alert('Edit shift dialog would open here');
                break;
            case 'reassign':
                alert('Reassign shift dialog would open here');
                break;
            case 'cancel':
                if (confirm('Are you sure you want to cancel this shift?')) {
                    alert('Shift cancelled');
                }
                break;
            case 'details':
                alert('Shift details modal would open here');
                break;
        }
    }

    handleRequestAction(e) {
        const action = e.target.textContent.toLowerCase();
        const row = e.target.closest('.table-row');
        const employeeName = row.querySelector('.employee-name').textContent;
        
        switch(action) {
            case 'view':
                this.viewRequest(employeeName);
                break;
            case 'approve':
                this.approveRequest(employeeName, row);
                break;
            case 'reject':
                this.rejectRequest(employeeName, row);
                break;
        }
    }

    viewRequest(employeeName) {
        alert(`Viewing request details for ${employeeName}`);
    }

    approveRequest(employeeName, row) {
        if (confirm(`Approve request from ${employeeName}?`)) {
            const statusBadge = row.querySelector('.status-badge');
            statusBadge.textContent = 'Approved';
            statusBadge.className = 'status-badge approved';
            statusBadge.style.backgroundColor = '#d4edda';
            statusBadge.style.color = '#155724';
            
            // Disable action buttons
            const actionButtons = row.querySelectorAll('.btn-action');
            actionButtons.forEach(btn => {
                btn.disabled = true;
                btn.style.opacity = '0.5';
            });
        }
    }

    rejectRequest(employeeName, row) {
        if (confirm(`Reject request from ${employeeName}?`)) {
            const statusBadge = row.querySelector('.status-badge');
            statusBadge.textContent = 'Rejected';
            statusBadge.className = 'status-badge rejected';
            statusBadge.style.backgroundColor = '#f8d7da';
            statusBadge.style.color = '#721c24';
            
            // Disable action buttons
            const actionButtons = row.querySelectorAll('.btn-action');
            actionButtons.forEach(btn => {
                btn.disabled = true;
                btn.style.opacity = '0.5';
            });
        }
    }

    // Utility method to add notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 16px;
            border-radius: 4px;
            color: white;
            font-weight: 500;
            z-index: 9999;
            animation: slideIn 0.3s ease;
        `;
        
        const colors = {
            info: '#007bff',
            success: '#28a745',
            warning: '#ffc107',
            error: '#dc3545'
        };
        
        notification.style.backgroundColor = colors[type] || colors.info;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .shift-card.reassignable {
        cursor: pointer;
        border: 2px dashed #007bff;
    }
    
    .shift-card.reassignable:hover {
        background-color: #f8f9ff;
    }
`;
document.head.appendChild(style);

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ShiftManagement();
    window.shiftModal = new ShiftModal();
});



// --- Begin popup.js content (ShiftModal class) ---

// Shift Modal Management
class ShiftModal {
    constructor() {
        this.modal = null;
        this.form = null;
        this.isOpen = false;
        
        this.init();
    }

    init() {
        this.modal = document.getElementById('assignShiftModal');
        this.form = document.getElementById('assignShiftForm');
        this.bindEvents();
        this.setDefaultDate();
    }

    bindEvents() {
        // Modal trigger button is handled externally in shift.js's createNewShift()

        // Close modal events
        const closeBtn = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeModal());
        }
        
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.closeModal());
        }

        // Close modal when clicking outside
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.closeModal();
            }
        });

        // Close modal on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isOpen) {
                this.closeModal();
            }
        });

        // Form submission
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));

        // Department-Employee synchronization
        const departmentSelect = document.getElementById('departmentSelect');
        const employeeSelect = document.getElementById('employeeSelect');
        
        if (departmentSelect && employeeSelect) {
            departmentSelect.addEventListener('change', () => {
                this.filterEmployeesByDepartment();
            });
        }
    }

    setDefaultDate() {
        const dateInput = document.getElementById('shiftDate');
        if (dateInput) {
            const today = new Date();
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            dateInput.value = tomorrow.toISOString().split('T')[0];
            dateInput.min = today.toISOString().split('T')[0];
        }
    }

    openModal() {
        this.modal.classList.add('show');
        this.isOpen = true;
        document.body.style.overflow = 'hidden';
        
        // Focus on first input
        setTimeout(() => {
            const firstInput = this.modal.querySelector('.form-select');
            if (firstInput) {
                firstInput.focus();
            }
        }, 100);
    }

    closeModal() {
        this.modal.classList.remove('show');
        this.isOpen = false;
        document.body.style.overflow = '';
        this.resetForm();
    }

    resetForm() {
        this.form.reset();
        this.setDefaultDate();
        this.removeMessage();
    }

    filterEmployeesByDepartment() {
        const departmentSelect = document.getElementById('departmentSelect');
        const employeeSelect = document.getElementById('employeeSelect');
        const selectedDept = departmentSelect.value;

        // Employee-Department mapping
        const employeeDepartments = {
            'sarah-johnson': 'sales',
            'jessica-lee': 'sales',
            'michael-chen': 'inventory',
            'james-wilson': 'inventory',
            'emily-wilson': 'marketing',
            'david-thompson': 'finance',
            'robert-kim': 'hr',
            'alex-rivera': 'it',
            'sophia-martinez': 'it'
        };

        // Show/hide employees based on department
        Array.from(employeeSelect.options).forEach(option => {
            if (option.value === '') return; // Keep default option
            
            const employeeId = option.value;
            const employeeDept = employeeDepartments[employeeId];
            
            if (selectedDept === '' || selectedDept === employeeDept) {
                option.style.display = 'block';
            } else {
                option.style.display = 'none';
            }
        });

        // Reset employee selection if current selection doesn't match department
        const currentEmployee = employeeSelect.value;
        if (currentEmployee && selectedDept && employeeDepartments[currentEmployee] !== selectedDept) {
            employeeSelect.value = '';
        }
    }

    handleSubmit(e) {
        e.preventDefault();
        
        if (!this.validateForm()) {
            return;
        }

        const formData = this.getFormData();
        this.submitShift(formData);
    }

    validateForm() {
        const requiredFields = ['employeeSelect', 'departmentSelect', 'shiftTypeSelect', 'shiftDate'];
        let isValid = true;

        requiredFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (!field.value.trim()) {
                field.style.borderColor = '#ef4444';
                isValid = false;
            } else {
                field.style.borderColor = '#10b981';
            }
        });

        // Validate date is not in the past
        const dateField = document.getElementById('shiftDate');
        const selectedDate = new Date(dateField.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate < today) {
            dateField.style.borderColor = '#ef4444';
            this.showMessage('Please select a future date', 'error');
            isValid = false;
        }

        return isValid;
    }

    getFormData() {
        return {
            employee: document.getElementById('employeeSelect').value,
            department: document.getElementById('departmentSelect').value,
            shiftType: document.getElementById('shiftTypeSelect').value,
            date: document.getElementById('shiftDate').value
        };
    }

    async submitShift(formData) {
        const submitBtn = document.querySelector('.btn-assign');
        const originalText = submitBtn.textContent;
        
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.textContent = 'Assigning...';

        try {
            // Simulate API call
            await this.simulateApiCall(formData);
            
            // Show success message
            this.showMessage('Shift assigned successfully!', 'success');
            
            // Close modal after delay
            setTimeout(() => {
                this.closeModal();
                this.notifyShiftAssigned(formData);
            }, 1500);
            
        } catch (error) {
            this.showMessage('Error assigning shift. Please try again.', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
        }
    }

    simulateApiCall(formData) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simulate 10% failure rate
                if (Math.random() < 0.1) {
                    reject(new Error('API Error'));
                } else {
                    resolve(formData);
                }
            }, 1000);
        });
    }

    showMessage(text, type) {
        this.removeMessage();
        
        const message = document.createElement('div');
        message.className = `form-message ${type}`;
        message.textContent = text;
        
        const form = document.getElementById('assignShiftForm');
        form.insertBefore(message, form.firstChild);
    }

    removeMessage() {
        const existingMessage = document.querySelector('.form-message');
        if (existingMessage) {
            existingMessage.remove();
        }
    }

    notifyShiftAssigned(formData) {
        // Notify the main shift management system
        if (window.shiftManagement && window.shiftManagement.showNotification) {
            window.shiftManagement.showNotification('Shift assigned successfully!', 'success');
        }
        
        // Dispatch custom event for other components to listen
        document.dispatchEvent(new CustomEvent('shiftAssigned', {
            detail: formData
        }));
    }

    // Public method to open modal from external code
    static open() {
        if (window.shiftModal) {
            window.shiftModal.openModal();
        }
    }

    // Public method to close modal from external code
    static close() {
        if (window.shiftModal) {
            window.shiftModal.closeModal();
        }
    }
}

// --- End popup.js content ---

